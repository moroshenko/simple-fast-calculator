git add --all
git push -u origin master
zip -r bin/calculator.zip *
